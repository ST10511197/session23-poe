# images/

- `gallery/` — real Session 23 event photography used on the Events page archive.
  Each photo ships as three widths (400/800/1600px) for the `srcset`/`sizes`
  responsive markup in `events.html`. Keep the same three filenames per photo when
  swapping in new photography, or update the `srcset` paths in `events.html` to match.
- `screenshots/` — device-width screenshots (desktop/tablet/mobile) used as Part 2
  evidence in the root `README.md`.
